These are the jet energy correction text files for the `Winter25Prompt25_V1` correction campaign
for 2025 samples.

The corrections should be applied to `Winter25` MC simulation. At the moment there are no DATA
corrections for 2025 samples.

The simulated response (MC truth) corrections for MC are presented in the reference(s) provided below.

[1] https://indico.cern.ch/event/1545816/#36-l2rel-for-winter25<br />

